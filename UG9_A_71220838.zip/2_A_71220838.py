suhufah = int(input ('Suhu dalam skala Fahrenheit: '))
celcius = int((5/9)*(suhufah-32))
print(suhufah, 'derajat Fahrenheit dikonversi menjadi', celcius, 'derajat Celcius') 
